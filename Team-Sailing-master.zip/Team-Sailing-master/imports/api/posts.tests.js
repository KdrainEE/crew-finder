//************************************************************
// Author: Katie Austin, Jimmy Lin, Scott Rachwal,
//         Brandon Rader, Adam Yallum
// Date:   4/30/2018
//
// Description: Used for posts unit testing.
//
// Last Modified: 4/30/2018
// Last Modified By:  Katie Austin
//************************************************************

import { Meteor } from 'meteor/meteor';

if (Meteor.isServer) {
  describe('Posts', () => {
    describe('methods', () => {
      it('can create new post (event)', () => {
      });
    });
  });
}
